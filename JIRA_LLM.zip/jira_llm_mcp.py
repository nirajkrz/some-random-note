#!/usr/bin/env python3
"""
JIRA LLM Model Context Protocol (MCP) Implementation
Enables natural language queries to JIRA with intelligent context management
"""

import os
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import requests
from requests.auth import HTTPBasicAuth
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class QueryType(Enum):
    """Enumeration of supported query types"""
    CREATE_TEST_CASES = "create_test_cases"
    FIND_DEPENDENCIES = "find_dependencies"
    GET_DELIVERY_HISTORY = "get_delivery_history"
    SUMMARIZE_DEFECTS = "summarize_defects"
    LIST_EPIC_STORIES = "list_epic_stories"
    GENERAL_QUERY = "general_query"

@dataclass
class JIRAConfig:
    """JIRA configuration settings"""
    base_url: str
    username: str
    api_token: str
    project_key: str
    
    def __post_init__(self):
        if not self.base_url.endswith('/'):
            self.base_url += '/'

@dataclass
class QueryContext:
    """Context information for query processing"""
    query_type: QueryType
    story_id: Optional[str] = None
    epic_id: Optional[str] = None
    release_version: Optional[str] = None
    time_period: Optional[str] = None
    additional_filters: Dict[str, Any] = None

class JIRAModelContextProtocol:
    """Main class implementing the JIRA MCP"""
    
    def __init__(self, config: JIRAConfig):
        self.config = config
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(config.username, config.api_token)
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })
        
        # Query pattern mappings
        self.query_patterns = {
            QueryType.CREATE_TEST_CASES: [
                r'create.*test.*cases?.*for.*story\s+([A-Z]+-\d+)',
                r'generate.*test.*cases?.*([A-Z]+-\d+)',
                r'test.*cases?.*story\s+([A-Z]+-\d+)'
            ],
            QueryType.FIND_DEPENDENCIES: [
                r'find.*dependencies.*story\s+([A-Z]+-\d+)',
                r'dependencies.*([A-Z]+-\d+)',
                r'what.*depends.*on.*([A-Z]+-\d+)'
            ],
            QueryType.GET_DELIVERY_HISTORY: [
                r'delivery.*history.*story\s+([A-Z]+-\d+)',
                r'history.*([A-Z]+-\d+)',
                r'when.*delivered.*([A-Z]+-\d+)'
            ],
            QueryType.SUMMARIZE_DEFECTS: [
                r'summarize.*defects.*release.*this month',
                r'defects.*this month',
                r'bugs.*current.*release'
            ],
            QueryType.LIST_EPIC_STORIES: [
                r'list.*stories.*epic.*release',
                r'summary.*stories.*epic',
                r'stories.*in.*epic.*([A-Z]+-\d+)'
            ]
        }
    
    def parse_natural_query(self, query: str) -> QueryContext:
        """Parse natural language query and extract context"""
        query_lower = query.lower()
        
        for query_type, patterns in self.query_patterns.items():
            for pattern in patterns:
                match = re.search(pattern, query_lower)
                if match:
                    context = QueryContext(query_type=query_type)
                    
                    # Extract story/epic ID if present
                    if match.groups():
                        story_match = re.search(r'([A-Z]+-\d+)', match.group(1).upper())
                        if story_match:
                            if 'epic' in query_lower:
                                context.epic_id = story_match.group(1)
                            else:
                                context.story_id = story_match.group(1)
                    
                    # Extract time periods
                    if 'this month' in query_lower:
                        context.time_period = 'current_month'
                    elif 'this week' in query_lower:
                        context.time_period = 'current_week'
                    
                    return context
        
        return QueryContext(query_type=QueryType.GENERAL_QUERY)
    
    def get_story_details(self, story_id: str) -> Dict[str, Any]:
        """Fetch detailed information about a JIRA story"""
        try:
            url = f"{self.config.base_url}rest/api/3/issue/{story_id}"
            response = self.session.get(url)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Error fetching story {story_id}: {e}")
            return {}
    
    def get_story_dependencies(self, story_id: str) -> List[Dict[str, Any]]:
        """Find dependencies for a story"""
        try:
            # Get issue links
            story_data = self.get_story_details(story_id)
            if not story_data:
                return []
            
            dependencies = []
            issue_links = story_data.get('fields', {}).get('issuelinks', [])
            
            for link in issue_links:
                if 'inwardIssue' in link:
                    dep = {
                        'key': link['inwardIssue']['key'],
                        'summary': link['inwardIssue']['fields']['summary'],
                        'status': link['inwardIssue']['fields']['status']['name'],
                        'relationship': link['type']['inward']
                    }
                    dependencies.append(dep)
                elif 'outwardIssue' in link:
                    dep = {
                        'key': link['outwardIssue']['key'],
                        'summary': link['outwardIssue']['fields']['summary'],
                        'status': link['outwardIssue']['fields']['status']['name'],
                        'relationship': link['type']['outward']
                    }
                    dependencies.append(dep)
            
            return dependencies
        except Exception as e:
            logger.error(f"Error finding dependencies for {story_id}: {e}")
            return []
    
    def get_delivery_history(self, story_id: str) -> Dict[str, Any]:
        """Get delivery and history information for a story"""
        try:
            # Get issue changelog
            url = f"{self.config.base_url}rest/api/3/issue/{story_id}/changelog"
            response = self.session.get(url)
            response.raise_for_status()
            changelog = response.json()
            
            story_data = self.get_story_details(story_id)
            
            history = {
                'story_id': story_id,
                'current_status': story_data.get('fields', {}).get('status', {}).get('name'),
                'created': story_data.get('fields', {}).get('created'),
                'updated': story_data.get('fields', {}).get('updated'),
                'resolution_date': story_data.get('fields', {}).get('resolutiondate'),
                'status_changes': []
            }
            
            for change_record in changelog.get('values', []):
                for item in change_record.get('items', []):
                    if item.get('field') == 'status':
                        status_change = {
                            'date': change_record.get('created'),
                            'author': change_record.get('author', {}).get('displayName'),
                            'from_status': item.get('fromString'),
                            'to_status': item.get('toString')
                        }
                        history['status_changes'].append(status_change)
            
            return history
        except Exception as e:
            logger.error(f"Error getting history for {story_id}: {e}")
            return {}
    
    def generate_test_cases(self, story_id: str) -> List[Dict[str, str]]:
        """Generate test cases based on story details"""
        story_data = self.get_story_details(story_id)
        if not story_data:
            return []
        
        fields = story_data.get('fields', {})
        summary = fields.get('summary', '')
        description = fields.get('description', {}).get('content', [])
        acceptance_criteria = self.extract_acceptance_criteria(description)
        
        test_cases = []
        
        # Generate basic functional test cases
        test_cases.extend([
            {
                'title': f'Verify {summary} - Happy Path',
                'description': f'Test the main functionality of {summary}',
                'steps': self.generate_test_steps(summary, 'positive'),
                'expected_result': 'Feature works as expected',
                'priority': 'High'
            },
            {
                'title': f'Verify {summary} - Edge Cases',
                'description': f'Test edge cases for {summary}',
                'steps': self.generate_test_steps(summary, 'edge'),
                'expected_result': 'System handles edge cases gracefully',
                'priority': 'Medium'
            },
            {
                'title': f'Verify {summary} - Error Handling',
                'description': f'Test error scenarios for {summary}',
                'steps': self.generate_test_steps(summary, 'negative'),
                'expected_result': 'Appropriate error messages displayed',
                'priority': 'Medium'
            }
        ])
        
        # Generate test cases from acceptance criteria
        for i, criteria in enumerate(acceptance_criteria, 1):
            test_cases.append({
                'title': f'Verify Acceptance Criteria {i} - {criteria[:50]}...',
                'description': f'Test acceptance criteria: {criteria}',
                'steps': self.generate_test_steps(criteria, 'acceptance'),
                'expected_result': 'Acceptance criteria is met',
                'priority': 'High'
            })
        
        return test_cases
    
    def extract_acceptance_criteria(self, content_blocks: List[Dict]) -> List[str]:
        """Extract acceptance criteria from story description"""
        criteria = []
        for block in content_blocks:
            if block.get('type') == 'paragraph':
                text = self.extract_text_from_content(block)
                if any(keyword in text.lower() for keyword in ['given', 'when', 'then', 'should', 'must']):
                    criteria.append(text)
        return criteria
    
    def extract_text_from_content(self, content_block: Dict) -> str:
        """Extract plain text from JIRA content structure"""
        if content_block.get('type') == 'text':
            return content_block.get('text', '')
        
        text = ''
        for item in content_block.get('content', []):
            text += self.extract_text_from_content(item)
        return text
    
    def generate_test_steps(self, context: str, test_type: str) -> str:
        """Generate test steps based on context and type"""
        if test_type == 'positive':
            return f"1. Navigate to the feature\n2. Execute {context}\n3. Verify successful completion"
        elif test_type == 'edge':
            return f"1. Set up edge case scenario\n2. Execute {context}\n3. Verify proper handling"
        elif test_type == 'negative':
            return f"1. Set up invalid conditions\n2. Attempt {context}\n3. Verify error handling"
        elif test_type == 'acceptance':
            return f"1. Set up test data\n2. Execute scenario: {context}\n3. Verify acceptance criteria"
        return "1. Prepare test\n2. Execute\n3. Verify"
    
    def summarize_defects_for_period(self, time_period: str = 'current_month') -> Dict[str, Any]:
        """Summarize defects for a given time period"""
        try:
            # Calculate date range
            now = datetime.now()
            if time_period == 'current_month':
                start_date = now.replace(day=1)
            elif time_period == 'current_week':
                start_date = now - timedelta(days=now.weekday())
            else:
                start_date = now - timedelta(days=30)
            
            # JIRA JQL query for bugs
            jql = f"""
            project = {self.config.project_key} AND 
            issuetype = Bug AND 
            created >= "{start_date.strftime('%Y-%m-%d')}"
            """
            
            url = f"{self.config.base_url}rest/api/3/search"
            params = {
                'jql': jql,
                'fields': 'summary,status,priority,created,assignee,components'
            }
            
            response = self.session.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            # Analyze defects
            defects = data.get('issues', [])
            summary = {
                'total_defects': len(defects),
                'period': time_period,
                'start_date': start_date.isoformat(),
                'status_breakdown': {},
                'priority_breakdown': {},
                'component_breakdown': {},
                'defects_list': []
            }
            
            for defect in defects:
                fields = defect.get('fields', {})
                
                # Status breakdown
                status = fields.get('status', {}).get('name', 'Unknown')
                summary['status_breakdown'][status] = summary['status_breakdown'].get(status, 0) + 1
                
                # Priority breakdown
                priority = fields.get('priority', {}).get('name', 'Unknown')
                summary['priority_breakdown'][priority] = summary['priority_breakdown'].get(priority, 0) + 1
                
                # Component breakdown
                components = fields.get('components', [])
                for comp in components:
                    comp_name = comp.get('name', 'No Component')
                    summary['component_breakdown'][comp_name] = summary['component_breakdown'].get(comp_name, 0) + 1
                
                # Add to defects list
                summary['defects_list'].append({
                    'key': defect.get('key'),
                    'summary': fields.get('summary'),
                    'status': status,
                    'priority': priority,
                    'created': fields.get('created'),
                    'assignee': fields.get('assignee', {}).get('displayName', 'Unassigned') if fields.get('assignee') else 'Unassigned'
                })
            
            return summary
        except Exception as e:
            logger.error(f"Error summarizing defects: {e}")
            return {}
    
    def list_epic_stories(self, epic_id: str = None, release_version: str = None) -> Dict[str, Any]:
        """List stories in an epic for a release"""
        try:
            # Build JQL query
            jql_parts = [f"project = {self.config.project_key}"]
            
            if epic_id:
                jql_parts.append(f'"Epic Link" = {epic_id}')
            
            if release_version:
                jql_parts.append(f'fixVersion = "{release_version}"')
            
            jql = " AND ".join(jql_parts)
            
            url = f"{self.config.base_url}rest/api/3/search"
            params = {
                'jql': jql,
                'fields': 'summary,status,assignee,storypoints,priority,epic'
            }
            
            response = self.session.get(url, params=params)
            response.raise_for_status()
            data = response.json()
            
            stories = data.get('issues', [])
            epic_summary = {
                'epic_id': epic_id,
                'release_version': release_version,
                'total_stories': len(stories),
                'status_breakdown': {},
                'total_story_points': 0,
                'stories': []
            }
            
            for story in stories:
                fields = story.get('fields', {})
                
                # Status breakdown
                status = fields.get('status', {}).get('name', 'Unknown')
                epic_summary['status_breakdown'][status] = epic_summary['status_breakdown'].get(status, 0) + 1
                
                # Story points
                story_points = fields.get('customfield_10016', 0) or 0  # Common story points field
                epic_summary['total_story_points'] += story_points
                
                # Add story details
                epic_summary['stories'].append({
                    'key': story.get('key'),
                    'summary': fields.get('summary'),
                    'status': status,
                    'assignee': fields.get('assignee', {}).get('displayName', 'Unassigned') if fields.get('assignee') else 'Unassigned',
                    'story_points': story_points,
                    'priority': fields.get('priority', {}).get('name', 'Unknown')
                })
            
            return epic_summary
        except Exception as e:
            logger.error(f"Error listing epic stories: {e}")
            return {}
    
    def process_query(self, natural_query: str) -> Dict[str, Any]:
        """Main method to process natural language queries"""
        logger.info(f"Processing query: {natural_query}")
        
        context = self.parse_natural_query(natural_query)
        result = {'query': natural_query, 'context': asdict(context)}
        
        try:
            if context.query_type == QueryType.CREATE_TEST_CASES and context.story_id:
                result['test_cases'] = self.generate_test_cases(context.story_id)
                result['story_details'] = self.get_story_details(context.story_id)
                
            elif context.query_type == QueryType.FIND_DEPENDENCIES and context.story_id:
                result['dependencies'] = self.get_story_dependencies(context.story_id)
                result['story_details'] = self.get_story_details(context.story_id)
                
            elif context.query_type == QueryType.GET_DELIVERY_HISTORY and context.story_id:
                result['delivery_history'] = self.get_delivery_history(context.story_id)
                
            elif context.query_type == QueryType.SUMMARIZE_DEFECTS:
                result['defect_summary'] = self.summarize_defects_for_period(
                    context.time_period or 'current_month'
                )
                
            elif context.query_type == QueryType.LIST_EPIC_STORIES:
                result['epic_stories'] = self.list_epic_stories(
                    context.epic_id, 
                    context.release_version
                )
                
            else:
                result['message'] = "Query type not supported or insufficient context provided"
                
        except Exception as e:
            logger.error(f"Error processing query: {e}")
            result['error'] = str(e)
        
        return result

def format_response(result: Dict[str, Any]) -> str:
    """Format the result into a human-readable response"""
    query_type = result.get('context', {}).get('query_type')
    
    if query_type == 'create_test_cases':
        test_cases = result.get('test_cases', [])
        story_details = result.get('story_details', {})
        
        response = f"Generated {len(test_cases)} test cases for story {result['context']['story_id']}:\n\n"
        response += f"Story: {story_details.get('fields', {}).get('summary', 'N/A')}\n\n"
        
        for i, tc in enumerate(test_cases, 1):
            response += f"{i}. {tc['title']}\n"
            response += f"   Priority: {tc['priority']}\n"
            response += f"   Steps: {tc['steps']}\n"
            response += f"   Expected: {tc['expected_result']}\n\n"
            
    elif query_type == 'find_dependencies':
        deps = result.get('dependencies', [])
        response = f"Found {len(deps)} dependencies for story {result['context']['story_id']}:\n\n"
        
        for dep in deps:
            response += f"• {dep['key']}: {dep['summary']}\n"
            response += f"  Status: {dep['status']} | Relationship: {dep['relationship']}\n\n"
            
    elif query_type == 'get_delivery_history':
        history = result.get('delivery_history', {})
        response = f"Delivery history for story {result['context']['story_id']}:\n\n"
        response += f"Current Status: {history.get('current_status')}\n"
        response += f"Created: {history.get('created')}\n"
        response += f"Last Updated: {history.get('updated')}\n"
        
        if history.get('resolution_date'):
            response += f"Resolved: {history.get('resolution_date')}\n"
        
        response += "\nStatus Changes:\n"
        for change in history.get('status_changes', []):
            response += f"• {change['date']}: {change['from_status']} → {change['to_status']} by {change['author']}\n"
            
    elif query_type == 'summarize_defects':
        summary = result.get('defect_summary', {})
        response = f"Defect Summary for {summary.get('period', 'period')}:\n\n"
        response += f"Total Defects: {summary.get('total_defects', 0)}\n\n"
        
        response += "Status Breakdown:\n"
        for status, count in summary.get('status_breakdown', {}).items():
            response += f"• {status}: {count}\n"
        
        response += "\nPriority Breakdown:\n"
        for priority, count in summary.get('priority_breakdown', {}).items():
            response += f"• {priority}: {count}\n"
            
    elif query_type == 'list_epic_stories':
        epic_data = result.get('epic_stories', {})
        response = f"Epic Stories Summary:\n\n"
        response += f"Total Stories: {epic_data.get('total_stories', 0)}\n"
        response += f"Total Story Points: {epic_data.get('total_story_points', 0)}\n\n"
        
        response += "Status Breakdown:\n"
        for status, count in epic_data.get('status_breakdown', {}).items():
            response += f"• {status}: {count}\n"
            
    else:
        response = "Unable to process the query. Please check the format and try again."
    
    return response

# Example usage and testing
if __name__ == "__main__":
    # Example configuration (replace with your actual JIRA details)
    config = JIRAConfig(
        base_url="https://your-domain.atlassian.net/",
        username="your-email@company.com",
        api_token="your-api-token",
        project_key="PROJ"
    )
    
    # Initialize the MCP
    jira_mcp = JIRAModelContextProtocol(config)
    
    # Example queries
    test_queries = [
        "Create relevant Test cases for story ABC-1234 using the story details",
        "Find out the dependencies on story ABC-1234",
        "Find out delivery and history for story ABC-1234",
        "Find out and summarize defects on release for this month",
        "List out the summary of stories on an epic in this release"
    ]
    
    for query in test_queries:
        print(f"\n{'='*50}")
        print(f"Query: {query}")
        print('='*50)
        
        result = jira_mcp.process_query(query)
        formatted_response = format_response(result)
        print(formatted_response)

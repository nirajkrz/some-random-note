#!/usr/bin/env python3
"""
JIRA Model Context Protocol Server
Provides LLM access to JIRA data for querying stories, defects, test cases, etc.
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional, Sequence
from urllib.parse import urljoin
import aiohttp
import base64
from datetime import datetime, timedelta

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("jira-mcp-server")

class JIRAClient:
    """JIRA REST API Client"""
    
    def __init__(self, base_url: str, username: str, api_token: str):
        self.base_url = base_url.rstrip('/')
        self.auth = base64.b64encode(f"{username}:{api_token}".encode()).decode()
        self.headers = {
            'Authorization': f'Basic {self.auth}',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        }
    
    async def _make_request(self, method: str, endpoint: str, params: Optional[Dict] = None, data: Optional[Dict] = None) -> Dict:
        """Make HTTP request to JIRA API"""
        url = urljoin(self.base_url, f"/rest/api/3/{endpoint}")
        
        async with aiohttp.ClientSession() as session:
            async with session.request(
                method=method,
                url=url,
                headers=self.headers,
                params=params,
                json=data
            ) as response:
                response.raise_for_status()
                return await response.json()
    
    async def get_issue(self, issue_key: str, expand: str = "changelog,transitions") -> Dict:
        """Get detailed information about a JIRA issue"""
        return await self._make_request('GET', f'issue/{issue_key}', params={'expand': expand})
    
    async def search_issues(self, jql: str, fields: str = "*all", max_results: int = 50) -> Dict:
        """Search for issues using JQL"""
        params = {
            'jql': jql,
            'fields': fields,
            'maxResults': max_results
        }
        return await self._make_request('GET', 'search', params=params)
    
    async def get_issue_transitions(self, issue_key: str) -> Dict:
        """Get available transitions for an issue"""
        return await self._make_request('GET', f'issue/{issue_key}/transitions')
    
    async def get_project(self, project_key: str) -> Dict:
        """Get project information"""
        return await self._make_request('GET', f'project/{project_key}')
    
    async def get_versions(self, project_key: str) -> List[Dict]:
        """Get project versions/releases"""
        return await self._make_request('GET', f'project/{project_key}/version')

class JIRAMCPServer:
    """JIRA MCP Server Implementation"""
    
    def __init__(self):
        self.server = Server("jira-mcp-server")
        self.jira_client: Optional[JIRAClient] = None
        self.setup_handlers()
    
    def setup_handlers(self):
        """Setup MCP server handlers"""
        
        @self.server.list_resources()
        async def list_resources() -> List[Resource]:
            """List available JIRA resources"""
            return [
                Resource(
                    uri="jira://projects",
                    name="JIRA Projects",
                    description="List of available JIRA projects"
                ),
                Resource(
                    uri="jira://issues/recent",
                    name="Recent Issues",
                    description="Recently updated issues"
                )
            ]
        
        @self.server.read_resource()
        async def read_resource(uri: str) -> str:
            """Read JIRA resource content"""
            if not self.jira_client:
                return "JIRA client not configured"
            
            if uri == "jira://projects":
                # This would require additional API calls to get all projects
                return "Use search_projects tool for project information"
            elif uri == "jira://issues/recent":
                recent_issues = await self.jira_client.search_issues(
                    jql="updated >= -7d ORDER BY updated DESC",
                    max_results=20
                )
                return json.dumps(recent_issues, indent=2)
            
            return f"Unknown resource: {uri}"
        
        @self.server.list_tools()
        async def list_tools() -> List[Tool]:
            """List available JIRA tools"""
            return [
                Tool(
                    name="get_story_details",
                    description="Get detailed information about a JIRA story/issue",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "issue_key": {
                                "type": "string",
                                "description": "JIRA issue key (e.g., ABC-1234)"
                            }
                        },
                        "required": ["issue_key"]
                    }
                ),
                Tool(
                    name="create_test_cases",
                    description="Generate test cases for a story based on its details",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "issue_key": {
                                "type": "string",
                                "description": "JIRA story key to create test cases for"
                            }
                        },
                        "required": ["issue_key"]
                    }
                ),
                Tool(
                    name="find_dependencies",
                    description="Find dependencies for a JIRA story",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "issue_key": {
                                "type": "string",
                                "description": "JIRA issue key to find dependencies for"
                            }
                        },
                        "required": ["issue_key"]
                    }
                ),
                Tool(
                    name="get_delivery_history",
                    description="Get delivery status and history for a story",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "issue_key": {
                                "type": "string",
                                "description": "JIRA issue key"
                            }
                        },
                        "required": ["issue_key"]
                    }
                ),
                Tool(
                    name="summarize_defects",
                    description="Summarize defects for a release or time period",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "release_version": {
                                "type": "string",
                                "description": "Release version (optional)"
                            },
                            "project_key": {
                                "type": "string",
                                "description": "Project key"
                            },
                            "days": {
                                "type": "integer",
                                "description": "Number of days to look back",
                                "default": 30
                            }
                        },
                        "required": ["project_key"]
                    }
                ),
                Tool(
                    name="summarize_epic_stories",
                    description="List and summarize stories in an epic for a release",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "epic_key": {
                                "type": "string",
                                "description": "Epic key"
                            },
                            "release_version": {
                                "type": "string",
                                "description": "Release version (optional)"
                            }
                        },
                        "required": ["epic_key"]
                    }
                ),
                Tool(
                    name="search_issues",
                    description="Search JIRA issues using JQL",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "jql": {
                                "type": "string",
                                "description": "JQL query string"
                            },
                            "max_results": {
                                "type": "integer",
                                "description": "Maximum number of results",
                                "default": 50
                            }
                        },
                        "required": ["jql"]
                    }
                )
            ]
        
        @self.server.call_tool()
        async def call_tool(name: str, arguments: Dict[str, Any]) -> List[TextContent]:
            """Handle tool calls"""
            if not self.jira_client:
                return [TextContent(
                    type="text",
                    text="Error: JIRA client not configured. Please set JIRA_URL, JIRA_USERNAME, and JIRA_API_TOKEN environment variables."
                )]
            
            try:
                if name == "get_story_details":
                    return await self._get_story_details(arguments["issue_key"])
                
                elif name == "create_test_cases":
                    return await self._create_test_cases(arguments["issue_key"])
                
                elif name == "find_dependencies":
                    return await self._find_dependencies(arguments["issue_key"])
                
                elif name == "get_delivery_history":
                    return await self._get_delivery_history(arguments["issue_key"])
                
                elif name == "summarize_defects":
                    return await self._summarize_defects(
                        arguments["project_key"],
                        arguments.get("release_version"),
                        arguments.get("days", 30)
                    )
                
                elif name == "summarize_epic_stories":
                    return await self._summarize_epic_stories(
                        arguments["epic_key"],
                        arguments.get("release_version")
                    )
                
                elif name == "search_issues":
                    return await self._search_issues(
                        arguments["jql"],
                        arguments.get("max_results", 50)
                    )
                
                else:
                    return [TextContent(
                        type="text",
                        text=f"Unknown tool: {name}"
                    )]
            
            except Exception as e:
                logger.error(f"Error calling tool {name}: {str(e)}")
                return [TextContent(
                    type="text",
                    text=f"Error: {str(e)}"
                )]
    
    async def _get_story_details(self, issue_key: str) -> List[TextContent]:
        """Get detailed story information"""
        issue = await self.jira_client.get_issue(issue_key)
        
        fields = issue.get('fields', {})
        result = {
            "key": issue.get('key'),
            "summary": fields.get('summary'),
            "description": fields.get('description'),
            "status": fields.get('status', {}).get('name'),
            "assignee": fields.get('assignee', {}).get('displayName') if fields.get('assignee') else "Unassigned",
            "reporter": fields.get('reporter', {}).get('displayName'),
            "priority": fields.get('priority', {}).get('name'),
            "issue_type": fields.get('issuetype', {}).get('name'),
            "created": fields.get('created'),
            "updated": fields.get('updated'),
            "fix_versions": [v.get('name') for v in fields.get('fixVersions', [])],
            "components": [c.get('name') for c in fields.get('components', [])],
            "labels": fields.get('labels', [])
        }
        
        return [TextContent(
            type="text",
            text=json.dumps(result, indent=2)
        )]
    
    async def _create_test_cases(self, issue_key: str) -> List[TextContent]:
        """Generate test cases based on story details"""
        issue = await self.jira_client.get_issue(issue_key)
        fields = issue.get('fields', {})
        
        summary = fields.get('summary', '')
        description = fields.get('description', '')
        
        # Generate test case suggestions based on story content
        test_cases = f"""
# Test Cases for {issue_key}: {summary}

Based on the story details, here are suggested test cases:

## Functional Test Cases:

1. **Positive Flow Test**
   - **Test Case ID**: TC_{issue_key}_001
   - **Description**: Verify the main functionality works as expected
   - **Steps**: [Based on story acceptance criteria]
   - **Expected Result**: Feature works according to requirements

2. **Negative Flow Test**
   - **Test Case ID**: TC_{issue_key}_002
   - **Description**: Verify error handling for invalid inputs
   - **Steps**: [Test with invalid data]
   - **Expected Result**: Appropriate error messages displayed

3. **Boundary Value Test**
   - **Test Case ID**: TC_{issue_key}_003
   - **Description**: Test with boundary values
   - **Steps**: [Test min/max values]
   - **Expected Result**: System handles boundary conditions properly

## Non-Functional Test Cases:

4. **Performance Test**
   - **Test Case ID**: TC_{issue_key}_004
   - **Description**: Verify response time is acceptable
   - **Expected Result**: Response time < 3 seconds

5. **Security Test**
   - **Test Case ID**: TC_{issue_key}_005
   - **Description**: Verify proper authentication/authorization
   - **Expected Result**: Unauthorized access is prevented

Note: Please customize these test cases based on the specific requirements and acceptance criteria of the story.
        """
        
        return [TextContent(type="text", text=test_cases)]
    
    async def _find_dependencies(self, issue_key: str) -> List[TextContent]:
        """Find issue dependencies"""
        issue = await self.jira_client.get_issue(issue_key)
        
        # Check for linked issues
        issue_links = issue.get('fields', {}).get('issuelinks', [])
        
        dependencies = {
            "blocks": [],
            "is_blocked_by": [],
            "relates_to": [],
            "duplicates": [],
            "other_links": []
        }
        
        for link in issue_links:
            link_type = link.get('type', {}).get('name', '').lower()
            
            if 'outwardIssue' in link:
                linked_issue = link['outwardIssue']
                link_info = {
                    "key": linked_issue.get('key'),
                    "summary": linked_issue.get('fields', {}).get('summary'),
                    "status": linked_issue.get('fields', {}).get('status', {}).get('name')
                }
                
                if 'block' in link_type:
                    dependencies["blocks"].append(link_info)
                elif 'relate' in link_type:
                    dependencies["relates_to"].append(link_info)
                elif 'duplicate' in link_type:
                    dependencies["duplicates"].append(link_info)
                else:
                    dependencies["other_links"].append(link_info)
            
            if 'inwardIssue' in link:
                linked_issue = link['inwardIssue']
                link_info = {
                    "key": linked_issue.get('key'),
                    "summary": linked_issue.get('fields', {}).get('summary'),
                    "status": linked_issue.get('fields', {}).get('status', {}).get('name')
                }
                
                if 'block' in link_type:
                    dependencies["is_blocked_by"].append(link_info)
                elif 'relate' in link_type:
                    dependencies["relates_to"].append(link_info)
                else:
                    dependencies["other_links"].append(link_info)
        
        return [TextContent(
            type="text",
            text=json.dumps(dependencies, indent=2)
        )]
    
    async def _get_delivery_history(self, issue_key: str) -> List[TextContent]:
        """Get issue delivery status and history"""
        issue = await self.jira_client.get_issue(issue_key, expand="changelog")
        
        fields = issue.get('fields', {})
        changelog = issue.get('changelog', {})
        
        history = []
        for change in changelog.get('histories', []):
            for item in change.get('items', []):
                if item.get('field') == 'status':
                    history.append({
                        "date": change.get('created'),
                        "author": change.get('author', {}).get('displayName'),
                        "from_status": item.get('fromString'),
                        "to_status": item.get('toString')
                    })
        
        delivery_info = {
            "issue_key": issue_key,
            "current_status": fields.get('status', {}).get('name'),
            "fix_versions": [v.get('name') for v in fields.get('fixVersions', [])],
            "resolution": fields.get('resolution', {}).get('name') if fields.get('resolution') else None,
            "resolved_date": fields.get('resolutiondate'),
            "status_history": history
        }
        
        return [TextContent(
            type="text",
            text=json.dumps(delivery_info, indent=2)
        )]
    
    async def _summarize_defects(self, project_key: str, release_version: Optional[str], days: int) -> List[TextContent]:
        """Summarize defects for a project/release"""
        # Build JQL query
        jql_parts = [f'project = "{project_key}"', 'type = Bug']
        
        if release_version:
            jql_parts.append(f'fixVersion = "{release_version}"')
        else:
            jql_parts.append(f'updated >= -{days}d')
        
        jql = ' AND '.join(jql_parts)
        
        results = await self.jira_client.search_issues(jql, max_results=100)
        issues = results.get('issues', [])
        
        # Analyze defects
        summary = {
            "total_defects": len(issues),
            "by_status": {},
            "by_priority": {},
            "by_severity": {},
            "critical_defects": []
        }
        
        for issue in issues:
            fields = issue.get('fields', {})
            status = fields.get('status', {}).get('name', 'Unknown')
            priority = fields.get('priority', {}).get('name', 'Unknown')
            
            # Count by status
            summary["by_status"][status] = summary["by_status"].get(status, 0) + 1
            
            # Count by priority
            summary["by_priority"][priority] = summary["by_priority"].get(priority, 0) + 1
            
            # Identify critical defects
            if priority.lower() in ['critical', 'highest', 'blocker']:
                summary["critical_defects"].append({
                    "key": issue.get('key'),
                    "summary": fields.get('summary'),
                    "status": status,
                    "assignee": fields.get('assignee', {}).get('displayName') if fields.get('assignee') else 'Unassigned'
                })
        
        return [TextContent(
            type="text",
            text=json.dumps(summary, indent=2)
        )]
    
    async def _summarize_epic_stories(self, epic_key: str, release_version: Optional[str]) -> List[TextContent]:
        """Summarize stories in an epic"""
        # Build JQL to find stories in epic
        jql = f'"Epic Link" = {epic_key}'
        if release_version:
            jql += f' AND fixVersion = "{release_version}"'
        
        results = await self.jira_client.search_issues(jql, max_results=100)
        issues = results.get('issues', [])
        
        # Get epic details
        epic = await self.jira_client.get_issue(epic_key)
        epic_fields = epic.get('fields', {})
        
        summary = {
            "epic": {
                "key": epic_key,
                "summary": epic_fields.get('summary'),
                "status": epic_fields.get('status', {}).get('name')
            },
            "total_stories": len(issues),
            "stories_by_status": {},
            "stories": []
        }
        
        for issue in issues:
            fields = issue.get('fields', {})
            status = fields.get('status', {}).get('name', 'Unknown')
            
            summary["stories_by_status"][status] = summary["stories_by_status"].get(status, 0) + 1
            
            summary["stories"].append({
                "key": issue.get('key'),
                "summary": fields.get('summary'),
                "status": status,
                "assignee": fields.get('assignee', {}).get('displayName') if fields.get('assignee') else 'Unassigned',
                "story_points": fields.get('customfield_10016')  # Common story points field
            })
        
        return [TextContent(
            type="text",
            text=json.dumps(summary, indent=2)
        )]
    
    async def _search_issues(self, jql: str, max_results: int) -> List[TextContent]:
        """Search issues using JQL"""
        results = await self.jira_client.search_issues(jql, max_results=max_results)
        return [TextContent(
            type="text",
            text=json.dumps(results, indent=2)
        )]
    
    def configure_jira_client(self, base_url: str, username: str, api_token: str):
        """Configure JIRA client"""
        self.jira_client = JIRAClient(base_url, username, api_token)
    
    async def run(self):
        """Run the MCP server"""
        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                InitializationOptions(
                    server_name="jira-mcp-server",
                    server_version="1.0.0",
                    capabilities=self.server.get_capabilities(
                        notification_options=None,
                        experimental_capabilities=None,
                    )
                )
            )

async def main():
    import os
    
    # Get JIRA configuration from environment variables
    jira_url = os.getenv('JIRA_URL')
    jira_username = os.getenv('JIRA_USERNAME')
    jira_api_token = os.getenv('JIRA_API_TOKEN')
    
    server = JIRAMCPServer()
    
    if jira_url and jira_username and jira_api_token:
        server.configure_jira_client(jira_url, jira_username, jira_api_token)
        logger.info("JIRA client configured successfully")
    else:
        logger.warning("JIRA configuration not found in environment variables")
    
    await server.run()

if __name__ == "__main__":
    asyncio.run(main())
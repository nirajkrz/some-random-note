# requirements.txt
requests>=2.31.0
python-dotenv>=1.0.0
pydantic>=2.0.0
fastapi>=0.100.0
uvicorn>=0.23.0

# config.yaml
jira:
  base_url: "${JIRA_BASE_URL}"
  username: "${JIRA_USERNAME}"
  api_token: "${JIRA_API_TOKEN}"
  project_key: "${JIRA_PROJECT_KEY}"
  
llm_settings:
  model: "gpt-4"
  temperature: 0.3
  max_tokens: 2000
  
query_patterns:
  test_case_keywords: ["test cases", "test scenarios", "testing", "verify", "validate"]
  dependency_keywords: ["dependencies", "depends on", "linked to", "blocking", "blocked by"]
  history_keywords: ["history", "delivery", "timeline", "status changes", "progression"]
  defect_keywords: ["defects", "bugs", "issues", "problems", "defect summary"]
  epic_keywords: ["epic", "stories", "summary", "list out"]

# .env (template)
JIRA_BASE_URL=https://your-domain.atlassian.net/
JIRA_USERNAME=your-email@company.com
JIRA_API_TOKEN=your-api-token-here
JIRA_PROJECT_KEY=PROJ
OPENAI_API_KEY=your-openai-api-key  # Optional for enhanced NLP

# app.py - FastAPI Web Service
from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import os
from dotenv import load_dotenv
from jira_mcp import JIRAModelContextProtocol, JIRAConfig, format_response

load_dotenv()

app = FastAPI(title="JIRA LLM Model Context Protocol API", version="1.0.0")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class QueryRequest(BaseModel):
    query: str
    project_key: Optional[str] = None

class QueryResponse(BaseModel):
    success: bool
    formatted_response: str
    raw_data: Dict[str, Any]
    error: Optional[str] = None

def get_jira_mcp() -> JIRAModelContextProtocol:
    """Dependency to get JIRA MCP instance"""
    config = JIRAConfig(
        base_url=os.getenv('JIRA_BASE_URL'),
        username=os.getenv('JIRA_USERNAME'),
        api_token=os.getenv('JIRA_API_TOKEN'),
        project_key=os.getenv('JIRA_PROJECT_KEY')
    )
    return JIRAModelContextProtocol(config)

@app.post("/query", response_model=QueryResponse)
async def process_natural_query(
    request: QueryRequest,
    jira_mcp: JIRAModelContextProtocol = Depends(get_jira_mcp)
):
    """Process natural language query and return formatted response"""
    try:
        # Override project key if provided
        if request.project_key:
            jira_mcp.config.project_key = request.project_key
        
        # Process the query
        result = jira_mcp.process_query(request.query)
        
        # Format the response
        formatted_response = format_response(result)
        
        return QueryResponse(
            success=True,
            formatted_response=formatted_response,
            raw_data=result
        )
    except Exception as e:
        return QueryResponse(
            success=False,
            formatted_response=f"Error processing query: {str(e)}",
            raw_data={},
            error=str(e)
        )

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "version": "1.0.0"}

@app.get("/query-examples")
async def get_query_examples():
    """Get example queries that the system supports"""
    return {
        "examples": [
            "Create relevant Test cases for story ABC-1234 using the story details",
            "Find out the dependencies on story ABC-1234",
            "Find out delivery and history for story ABC-1234", 
            "Find out and summarize defects on release for this month",
            "List out the summary of stories on an epic in this release",
            "What are the test cases for story PROJ-456?",
            "Show me all bugs created this week",
            "What stories are in epic PROJ-100?",
            "Get the status history for PROJ-789"
        ]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

# cli.py - Command Line Interface
import argparse
import sys
import json
from dotenv import load_dotenv
from jira_mcp import JIRAModelContextProtocol, JIRAConfig, format_response

def main():
    """Command line interface for JIRA MCP"""
    load_dotenv()
    
    parser = argparse.ArgumentParser(description="JIRA LLM Model Context Protocol CLI")
    parser.add_argument("query", help="Natural language query")
    parser.add_argument("--project", help="Override project key")
    parser.add_argument("--json", action="store_true", help="Output raw JSON")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    # Initialize JIRA MCP
    try:
        config = JIRAConfig(
            base_url=os.getenv('JIRA_BASE_URL'),
            username=os.getenv('JIRA_USERNAME'), 
            api_token=os.getenv('JIRA_API_TOKEN'),
            project_key=args.project or os.getenv('JIRA_PROJECT_KEY')
        )
        
        jira_mcp = JIRAModelContextProtocol(config)
        
        if args.verbose:
            print(f"Processing query: {args.query}